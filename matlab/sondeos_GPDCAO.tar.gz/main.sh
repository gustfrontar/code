#!/bin/bash
####################################################################################################
# Este script controla las estaciones para las cuales se realiza el analisis termodinamico con MATLAB
#
# -- Juan Ruiz 2006 ---
####################################################################################################

date=`date +%Y%m%d`
ciclo=$1            #12 o 00 decide que estaciones se disparan.

path=/sondeos_GPDCAO/                           #Donde estan los scripts.
webpath=/WRFV2/wrfsi/domains/operativo/www/     #Donde se generan las paginas web.

cd ${path}

anio=`echo ${date} | cut -c1-4`    #Año de comienzo de la corrida.
nmes=`echo ${date} | cut -c5-6`   #Mes de comienzo de la corrida.
dia=`echo ${date} | cut -c7-8`     #Dia de comienzo de la corrida.
                                                                                                               
                                                                                                               
case ${nmes} in
 01) mes=enero;;
 02) mes=febrero;;
 03) mes=marzo;;
 04) mes=abril;;
 05) mes=mayo;;
 06) mes=junio;;
 07) mes=julio;;
 08) mes=agosto;;
 09) mes=septiembre;;
 10) mes=octubre;;
 11) mes=noviembre;;
 12) mes=diciembre;;
 *) echo "Bad Month --> ${nmes} <--  EXITING!!..."; exit 8;;
esac

echo $ciclo


if  [ $ciclo -eq 12 ]
then
echo "Trayendo Ezeiza"
${path}procesa_sondeo.sh ${date}${ciclo} 87576             
${path}make_web.sh ${webpath} ${anio} ${mes} ${dia} ${ciclo} Ezeiza 87576 
echo "Trayendo Santa Rosa"
${path}procesa_sondeo.sh ${date}${ciclo} 87623
${path}make_web.sh ${webpath} ${anio} ${mes} ${dia} ${ciclo} Santa_Rosa 87623
echo "Trayendo Cordoba"
${path}procesa_sondeo.sh ${date}${ciclo} 87344
${path}make_web.sh ${webpath} ${anio} ${mes} ${dia} ${ciclo} Cordoba 87344
echo "Trayendo Resistencia"
${path}procesa_sondeo.sh ${date}${ciclo} 87155
${path}make_web.sh ${webpath} ${anio} ${mes} ${dia} ${ciclo} Resistencia 87155
echo "Trayendo Iguazu"
${path}procesa_sondeo.sh ${date}${ciclo} 83827
${path}make_web.sh ${webpath} ${anio} ${mes} ${dia} ${ciclo} Iguazu 83827
echo "Trayendo Comodoro"
${path}procesa_sondeo.sh ${date}${ciclo} 87860
${path}make_web.sh ${webpath} ${anio} ${mes} ${dia} ${ciclo} Comodoro 87860
echo "Trayendo Malvinas"
${path}procesa_sondeo.sh ${date}${ciclo} 88889
${path}make_web.sh ${webpath} ${anio} ${mes} ${dia} ${ciclo} Malvinas 88889

fi


if  [ $ciclo -eq 0 ]
then
echo ""
#${path}procesa_sondeo.sh ${date}${ciclo} 87576
fi
exit




