%Este script baja los datos de wyoming y procesa los sondeos hasta obtener las figuras.
clear all
close all

webpath='/home/wrf/imagenes/sondeos/'


horas=[00 12];

estaciones=[83827 83928 83937 87047 87155 87344 87418 87576 87623 87860 88889]

%==========================================================================
% Loop sobre las estaciones y las horas.
%==========================================================================

for jj=1:length(estaciones)
for ii=1:length(horas)

horasondeo=horas(ii);

today=date;
tmp=datenum(today);
today=datestr(tmp,'yyyymmdd');


filename=['TEMP_' num2str(estaciones(jj)) '_'  today '_' num2str(horasondeo) ];

URL=['http://weather.uwyo.edu/cgi-bin/sounding?region=samer&TYPE=TEXT%3ALIST&YEAR=' datestr(tmp,'yyyy') '&MONTH=' datestr(tmp,'mm') '&FROM=' datestr(tmp,'dd') num2str(horas(ii)) '&TO=' datestr(tmp,'dd') num2str(horas(ii)) '&STNM=' num2str(estaciones(jj)) ];

%Bajamos los datos
urlwrite(URL,filename)

[TPERFIL,TDPERFIL,PPERFIL,VELPERFIL,DIRPERFIL]=read_temp_wyoming_fun(filename);

if( sum(isnan(PPERFIL)) < length(PPERFIL))

tmp_fecha=str2num(datestr(tmp,'ddmmyyyy'));
sondeo_fun(PPERFIL,TPERFIL,TDPERFIL,VELPERFIL,DIRPERFIL,estaciones(jj),tmp_fecha,horas(ii));

else
    
display(['Warning: No pude bajar los datos']);


end
end

copyfile('*.png',webpath)


end


